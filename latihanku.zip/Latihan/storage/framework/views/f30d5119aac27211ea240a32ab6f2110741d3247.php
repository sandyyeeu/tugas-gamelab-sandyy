<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light border-bottom">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
            <a href="<?php echo e(route('dashboard')); ?>" class="nav-link">Dashboard</a>
        </li>
    </ul>

    

    
</nav>
<!-- /.navbar -->
<?php /**PATH C:\xampp\htdocs\jurusan\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>